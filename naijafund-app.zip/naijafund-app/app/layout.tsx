import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'NaijaFund MFB — Core Banking Platform',
  description: 'Secure microfinance banking platform for Nigeria. Manage loans, savings, clients and transactions.',
  keywords: 'microfinance, MFB, Nigeria, banking, loans, savings, CBN',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,400&family=Playfair+Display:wght@700;800;900&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet" />
      </head>
      <body className="font-sans bg-mfb-bg text-mfb-text antialiased">{children}</body>
    </html>
  )
}
